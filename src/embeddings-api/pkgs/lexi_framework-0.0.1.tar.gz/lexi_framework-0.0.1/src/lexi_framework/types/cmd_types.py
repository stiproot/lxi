from enum import Enum


class CmdTypes(Enum):
    BUILD_WORKFLOW = "BUILD_WORKFLOW"
    EMBED_REPO = "EMBED_REPO"
