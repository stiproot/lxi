Common module for Lexi.
