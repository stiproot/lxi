from enum import Enum


class QryTypes(Enum):
    QRY_REPO = "QRY_REPO"
